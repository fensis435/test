#!/usr/bin/env bash
# =============================================================================
# EKS Full-Stack Deployment Script
# Deploys: VPC, KMS, Cognito, WAF, SG, IAM, EKS, EFS, RDS, Karpenter, ArgoCD
# =============================================================================
set -euo pipefail
IFS=$'\n\t'

# ── Color output ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

log()    { echo -e "${GREEN}[$(date '+%H:%M:%S')] ✓ $*${NC}"; }
info()   { echo -e "${BLUE}[$(date '+%H:%M:%S')] ℹ $*${NC}"; }
warn()   { echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠ $*${NC}"; }
error()  { echo -e "${RED}[$(date '+%H:%M:%S')] ✗ $*${NC}" >&2; }
header() { echo -e "\n${CYAN}══════════════════════════════════════════\n  $*\n══════════════════════════════════════════${NC}"; }

# ── Configuration ─────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CFN_DIR="${SCRIPT_DIR}/cloudformation"
HELM_DIR="${SCRIPT_DIR}/helm"
ARGOCD_DIR="${SCRIPT_DIR}/argocd"

# Required — set via environment or edit here
PROJECT_NAME="${PROJECT_NAME:-eks-project}"
ENVIRONMENT="${ENVIRONMENT:-prod}"
AWS_REGION="${AWS_REGION:-ap-northeast-1}"
DOMAIN_NAME="${DOMAIN_NAME:-}"          # e.g. example.com
HOSTED_ZONE_ID="${HOSTED_ZONE_ID:-}"    # Route53 Hosted Zone ID
ARGOCD_REPO_URL="${ARGOCD_REPO_URL:-}"  # Git repo URL for GitOps
ARGOCD_REPO_PATH="${ARGOCD_REPO_PATH:-apps}"
NOTIFICATION_EMAIL="${NOTIFICATION_EMAIL:-}"

# Derived
CLUSTER_NAME="${PROJECT_NAME}-${ENVIRONMENT}"
STACK_PREFIX="${PROJECT_NAME}-${ENVIRONMENT}"

# Tool versions
KARPENTER_VERSION="1.0.8"
ARGOCD_VERSION="7.6.12"
ALB_CONTROLLER_VERSION="1.9.2"
METRICS_SERVER_VERSION="3.12.2"

# ── Prerequisites check ───────────────────────────────────────────────────────
check_prerequisites() {
  header "Checking Prerequisites"
  local missing=()
  local tools=("aws" "kubectl" "helm" "jq" "curl")

  for tool in "${tools[@]}"; do
    if command -v "$tool" &>/dev/null; then
      log "$tool: $(${tool} --version 2>&1 | head -1)"
    else
      missing+=("$tool")
      error "Missing: $tool"
    fi
  done

  [[ ${#missing[@]} -gt 0 ]] && { error "Install missing tools: ${missing[*]}"; exit 1; }

  # Validate required variables
  local required_vars=("DOMAIN_NAME" "HOSTED_ZONE_ID" "ARGOCD_REPO_URL")
  for var in "${required_vars[@]}"; do
    [[ -z "${!var}" ]] && { error "Required variable not set: $var"; exit 1; }
  done

  # AWS credentials check
  AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text --region "${AWS_REGION}")
  log "AWS Account: ${AWS_ACCOUNT_ID}, Region: ${AWS_REGION}"
}

# ── CloudFormation stack deploy helper ───────────────────────────────────────
deploy_stack() {
  local stack_name="$1"
  local template_file="$2"
  local parameters="${3:-}"

  info "Deploying stack: ${stack_name}"

  local cmd="aws cloudformation deploy \
    --stack-name ${stack_name} \
    --template-file ${template_file} \
    --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND \
    --region ${AWS_REGION} \
    --no-fail-on-empty-changeset"

  [[ -n "$parameters" ]] && cmd+=" --parameter-overrides ${parameters}"

  eval "$cmd"
  log "Stack deployed: ${stack_name}"

  # Wait for completion
  aws cloudformation wait stack-update-complete \
    --stack-name "${stack_name}" \
    --region "${AWS_REGION}" 2>/dev/null || true
}

# ── Get CloudFormation output ─────────────────────────────────────────────────
get_output() {
  local stack_name="$1"
  local output_key="$2"
  aws cloudformation describe-stacks \
    --stack-name "${stack_name}" \
    --region "${AWS_REGION}" \
    --query "Stacks[0].Outputs[?OutputKey=='${output_key}'].OutputValue" \
    --output text
}

# ── Phase 1: Base Infrastructure ──────────────────────────────────────────────
deploy_base() {
  header "Phase 1: Base Infrastructure (VPC, KMS, Cognito, Route53, ACM)"

  deploy_stack \
    "${STACK_PREFIX}-base" \
    "${CFN_DIR}/01-base.yaml" \
    "ProjectName=${PROJECT_NAME} Environment=${ENVIRONMENT} DomainName=${DOMAIN_NAME} HostedZoneId=${HOSTED_ZONE_ID}"

  log "Waiting for ACM certificate validation (DNS)..."
  CERT_ARN=$(get_output "${STACK_PREFIX}-base" "ACMCertificateArn")
  aws acm wait certificate-validated \
    --certificate-arn "${CERT_ARN}" \
    --region "${AWS_REGION}" || warn "Certificate validation timeout - check DNS records"
}

# ── Phase 2: Security (SG, WAF) ───────────────────────────────────────────────
deploy_security() {
  header "Phase 2: Security Groups & WAF"
  deploy_stack \
    "${STACK_PREFIX}-security" \
    "${CFN_DIR}/02-security.yaml" \
    "ProjectName=${PROJECT_NAME} Environment=${ENVIRONMENT}"
}

# ── Phase 3: IAM Roles ────────────────────────────────────────────────────────
deploy_iam() {
  header "Phase 3: IAM Roles & Karpenter SQS"
  deploy_stack \
    "${STACK_PREFIX}-iam" \
    "${CFN_DIR}/03-iam.yaml" \
    "ProjectName=${PROJECT_NAME} Environment=${ENVIRONMENT}"
}

# ── Phase 4: EKS Cluster + EFS + RDS ─────────────────────────────────────────
deploy_eks_rds_efs() {
  header "Phase 4: EKS Cluster, EFS, RDS PostgreSQL"
  deploy_stack \
    "${STACK_PREFIX}-eks-rds-efs" \
    "${CFN_DIR}/04-eks-rds-efs.yaml" \
    "ProjectName=${PROJECT_NAME} Environment=${ENVIRONMENT}"

  # Update kubeconfig
  info "Updating kubeconfig..."
  aws eks update-kubeconfig \
    --name "${CLUSTER_NAME}" \
    --region "${AWS_REGION}" \
    --alias "${CLUSTER_NAME}"

  # Wait for cluster to be active
  info "Waiting for EKS cluster to be ACTIVE..."
  aws eks wait cluster-active \
    --name "${CLUSTER_NAME}" \
    --region "${AWS_REGION}"

  log "EKS cluster is active: ${CLUSTER_NAME}"
}

# ── Phase 5: Helm repositories ───────────────────────────────────────────────
setup_helm_repos() {
  header "Phase 5: Setup Helm Repositories"
  helm repo add karpenter https://charts.karpenter.sh
  helm repo add aws-load-balancer-controller https://aws.github.io/eks-charts
  helm repo add argo https://argoproj.github.io/argo-helm
  helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server
  helm repo add external-secrets https://charts.external-secrets.io
  helm repo update
  log "Helm repositories configured"
}

# ── Phase 6: Karpenter ────────────────────────────────────────────────────────
deploy_karpenter() {
  header "Phase 6: Deploy Karpenter"

  KARPENTER_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "KarpenterControllerRoleArn")
  KARPENTER_QUEUE_NAME=$(get_output "${STACK_PREFIX}-iam" "KarpenterInterruptionQueueName")
  NODE_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "EKSNodeRoleArn")
  EBS_KMS_KEY_ARN=$(get_output "${STACK_PREFIX}-base" "EBSKMSKeyArn")

  # Create karpenter namespace
  kubectl create namespace karpenter --dry-run=client -o yaml | kubectl apply -f -

  # Pod Identity Association for Karpenter
  info "Creating Pod Identity association for Karpenter..."
  aws eks create-pod-identity-association \
    --cluster-name "${CLUSTER_NAME}" \
    --namespace karpenter \
    --service-account karpenter \
    --role-arn "${KARPENTER_ROLE_ARN}" \
    --region "${AWS_REGION}" 2>/dev/null || \
  aws eks update-pod-identity-association \
    --cluster-name "${CLUSTER_NAME}" \
    --namespace karpenter \
    --service-account karpenter \
    --role-arn "${KARPENTER_ROLE_ARN}" \
    --region "${AWS_REGION}" 2>/dev/null || true

  # Install Karpenter via Helm
  helm upgrade --install karpenter karpenter/karpenter \
    --namespace karpenter \
    --version "${KARPENTER_VERSION}" \
    --set "settings.clusterName=${CLUSTER_NAME}" \
    --set "settings.interruptionQueue=${KARPENTER_QUEUE_NAME}" \
    --set "serviceAccount.name=karpenter" \
    --set controller.resources.requests.cpu=250m \
    --set controller.resources.requests.memory=512Mi \
    --set controller.resources.limits.cpu=1 \
    --set controller.resources.limits.memory=1Gi \
    --set replicas=2 \
    --set topologySpreadConstraints[0].maxSkew=1 \
    --set topologySpreadConstraints[0].topologyKey=kubernetes.io/hostname \
    --set topologySpreadConstraints[0].whenUnsatisfiable=DoNotSchedule \
    --node-selector role=karpenter-system \
    --tolerations '[{"key":"CriticalAddonsOnly","operator":"Exists","effect":"NoSchedule"}]' \
    --wait --timeout 5m

  log "Karpenter deployed"

  # Apply Karpenter NodeClass and NodePool
  NODE_ROLE_NAME=$(echo "${NODE_ROLE_ARN}" | cut -d'/' -f2)
  PRIVATE_SUBNET_1=$(get_output "${STACK_PREFIX}-base" "PrivateSubnet1Id")
  PRIVATE_SUBNET_2=$(get_output "${STACK_PREFIX}-base" "PrivateSubnet2Id")
  PRIVATE_SUBNET_3=$(get_output "${STACK_PREFIX}-base" "PrivateSubnet3Id")

  cat <<EOF | kubectl apply -f -
apiVersion: karpenter.k8s.aws/v1
kind: EC2NodeClass
metadata:
  name: default
spec:
  amiFamily: AL2023
  role: "${NODE_ROLE_NAME}"
  subnetSelectorTerms:
    - tags:
        karpenter.sh/discovery: "${CLUSTER_NAME}"
  securityGroupSelectorTerms:
    - tags:
        karpenter.sh/discovery: "${CLUSTER_NAME}"
  blockDeviceMappings:
    - deviceName: /dev/xvda
      ebs:
        volumeSize: 100Gi
        volumeType: gp3
        encrypted: true
        kmsKeyID: "${EBS_KMS_KEY_ARN}"
        deleteOnTermination: true
        throughput: 200
        iops: 3000
  metadataOptions:
    httpEndpoint: enabled
    httpProtocolIPv6: disabled
    httpPutResponseHopLimit: 1
    httpTokens: required
  tags:
    Project: "${PROJECT_NAME}"
    Environment: "${ENVIRONMENT}"
    ManagedBy: karpenter
---
apiVersion: karpenter.sh/v1
kind: NodePool
metadata:
  name: default
spec:
  template:
    metadata:
      labels:
        role: worker
    spec:
      nodeClassRef:
        group: karpenter.k8s.aws
        kind: EC2NodeClass
        name: default
      requirements:
        - key: karpenter.k8s.aws/instance-category
          operator: In
          values: [m, c, r]
        - key: karpenter.k8s.aws/instance-generation
          operator: Gt
          values: ["5"]
        - key: kubernetes.io/arch
          operator: In
          values: [amd64]
        - key: karpenter.sh/capacity-type
          operator: In
          values: [spot, on-demand]
        - key: karpenter.k8s.aws/instance-size
          operator: NotIn
          values: [nano, micro, small, medium, metal]
      expireAfter: 720h
      terminationGracePeriod: 48h
  limits:
    cpu: "200"
    memory: 800Gi
  disruption:
    consolidationPolicy: WhenEmptyOrUnderutilized
    consolidateAfter: 1m
---
apiVersion: karpenter.sh/v1
kind: NodePool
metadata:
  name: gpu
spec:
  template:
    metadata:
      labels:
        role: gpu-worker
    spec:
      nodeClassRef:
        group: karpenter.k8s.aws
        kind: EC2NodeClass
        name: default
      requirements:
        - key: karpenter.k8s.aws/instance-category
          operator: In
          values: [g, p]
        - key: karpenter.sh/capacity-type
          operator: In
          values: [spot, on-demand]
      taints:
        - key: nvidia.com/gpu
          effect: NoSchedule
  limits:
    cpu: "64"
    memory: 256Gi
  disruption:
    consolidationPolicy: WhenEmpty
    consolidateAfter: 30s
EOF

  log "Karpenter NodeClass and NodePools applied"
}

# ── Phase 7: AWS Load Balancer Controller ─────────────────────────────────────
deploy_alb_controller() {
  header "Phase 7: AWS Load Balancer Controller"

  ALB_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "ALBControllerRoleArn")

  kubectl create namespace aws-load-balancer --dry-run=client -o yaml | kubectl apply -f -

  # Pod Identity Association
  aws eks create-pod-identity-association \
    --cluster-name "${CLUSTER_NAME}" \
    --namespace aws-load-balancer \
    --service-account aws-load-balancer-controller \
    --role-arn "${ALB_ROLE_ARN}" \
    --region "${AWS_REGION}" 2>/dev/null || true

  helm upgrade --install aws-load-balancer-controller \
    aws-load-balancer-controller/aws-load-balancer-controller \
    --namespace aws-load-balancer \
    --version "${ALB_CONTROLLER_VERSION}" \
    --set clusterName="${CLUSTER_NAME}" \
    --set serviceAccount.name=aws-load-balancer-controller \
    --set region="${AWS_REGION}" \
    --set vpcId="$(get_output "${STACK_PREFIX}-base" "VpcId")" \
    --set replicaCount=2 \
    --set tolerations[0].key=CriticalAddonsOnly \
    --set tolerations[0].operator=Exists \
    --set tolerations[0].effect=NoSchedule \
    --set nodeSelector.role=karpenter-system \
    --wait --timeout 5m

  log "AWS Load Balancer Controller deployed"
}

# ── Phase 8: Storage Classes ──────────────────────────────────────────────────
deploy_storage_classes() {
  header "Phase 8: EBS & EFS Storage Classes"

  EBS_KMS_KEY_ARN=$(get_output "${STACK_PREFIX}-base" "EBSKMSKeyArn")
  EFS_FS_ID=$(get_output "${STACK_PREFIX}-eks-rds-efs" "EFSFileSystemId")
  EFS_AP_ID=$(get_output "${STACK_PREFIX}-eks-rds-efs" "EFSAccessPointId")

  cat <<EOF | kubectl apply -f -
# EBS Storage Class (gp3, encrypted)
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: ebs-gp3-encrypted
  annotations:
    storageclass.kubernetes.io/is-default-class: "true"
provisioner: ebs.csi.aws.com
volumeBindingMode: WaitForFirstConsumer
reclaimPolicy: Retain
allowVolumeExpansion: true
parameters:
  type: gp3
  encrypted: "true"
  kmsKeyId: "${EBS_KMS_KEY_ARN}"
  throughput: "200"
  iops: "3000"
---
# EBS Storage Class - High Performance (io2)
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: ebs-io2-encrypted
provisioner: ebs.csi.aws.com
volumeBindingMode: WaitForFirstConsumer
reclaimPolicy: Retain
allowVolumeExpansion: true
parameters:
  type: io2
  encrypted: "true"
  kmsKeyId: "${EBS_KMS_KEY_ARN}"
  iops: "16000"
---
# EFS Storage Class (ReadWriteMany)
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: efs-sc
provisioner: efs.csi.aws.com
reclaimPolicy: Retain
volumeBindingMode: Immediate
parameters:
  provisioningMode: efs-ap
  fileSystemId: "${EFS_FS_ID}"
  directoryPerms: "755"
  uid: "1000"
  gid: "1000"
EOF

  log "Storage classes created"
}

# ── Phase 9: Metrics Server ───────────────────────────────────────────────────
deploy_metrics_server() {
  header "Phase 9: Metrics Server"
  helm upgrade --install metrics-server metrics-server/metrics-server \
    --namespace kube-system \
    --version "${METRICS_SERVER_VERSION}" \
    --set replicas=2 \
    --wait --timeout 3m
  log "Metrics server deployed"
}

# ── Phase 10: ArgoCD ─────────────────────────────────────────────────────────
deploy_argocd() {
  header "Phase 10: ArgoCD (GitOps)"

  ARGOCD_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "ArgoCDRoleArn")
  CERT_ARN=$(get_output "${STACK_PREFIX}-base" "ACMCertificateArn")
  WAF_ARN=$(get_output "${STACK_PREFIX}-security" "WAFWebACLArn")
  ALB_SG_ID=$(get_output "${STACK_PREFIX}-security" "ALBSecurityGroupId")

  kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -

  # Pod Identity for ArgoCD
  aws eks create-pod-identity-association \
    --cluster-name "${CLUSTER_NAME}" \
    --namespace argocd \
    --service-account argocd-server \
    --role-arn "${ARGOCD_ROLE_ARN}" \
    --region "${AWS_REGION}" 2>/dev/null || true

  helm upgrade --install argocd argo/argo-cd \
    --namespace argocd \
    --version "${ARGOCD_VERSION}" \
    --values - <<HELMVALUES
global:
  domain: argocd.${DOMAIN_NAME}

server:
  replicas: 2
  autoscaling:
    enabled: true
    minReplicas: 2
    maxReplicas: 5
  ingress:
    enabled: true
    ingressClassName: alb
    annotations:
      alb.ingress.kubernetes.io/scheme: internet-facing
      alb.ingress.kubernetes.io/target-type: ip
      alb.ingress.kubernetes.io/certificate-arn: "${CERT_ARN}"
      alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS13-1-2-2021-06
      alb.ingress.kubernetes.io/wafv2-acl-arn: "${WAF_ARN}"
      alb.ingress.kubernetes.io/security-groups: "${ALB_SG_ID}"
      alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
      alb.ingress.kubernetes.io/ssl-redirect: "443"
      alb.ingress.kubernetes.io/healthcheck-path: /healthz
      alb.ingress.kubernetes.io/healthcheck-port: "8080"
    hosts:
      - argocd.${DOMAIN_NAME}
    tls:
      - secretName: argocd-tls
        hosts:
          - argocd.${DOMAIN_NAME}

repoServer:
  replicas: 2
  autoscaling:
    enabled: true
    minReplicas: 2
    maxReplicas: 5

applicationSet:
  replicas: 2

configs:
  params:
    server.insecure: true
  cm:
    url: https://argocd.${DOMAIN_NAME}
    exec.enabled: "false"
    admin.enabled: "true"
    resource.compareoptions: |
      ignoreAggregatedRoles: true
HELMVALUES

  log "ArgoCD deployed"

  # Wait for ArgoCD to be ready
  info "Waiting for ArgoCD pods..."
  kubectl wait --for=condition=ready pod \
    -l app.kubernetes.io/name=argocd-server \
    -n argocd \
    --timeout=300s

  # Get initial admin password
  ARGOCD_INITIAL_PASSWORD=$(kubectl get secret argocd-initial-admin-secret \
    -n argocd \
    -o jsonpath='{.data.password}' | base64 -d)

  info "ArgoCD admin password: ${ARGOCD_INITIAL_PASSWORD}"
  info "Store this securely and change it immediately!"

  # Save to AWS Secrets Manager
  aws secretsmanager create-secret \
    --name "${PROJECT_NAME}/${ENVIRONMENT}/argocd/admin-password" \
    --secret-string "${ARGOCD_INITIAL_PASSWORD}" \
    --region "${AWS_REGION}" 2>/dev/null || \
  aws secretsmanager update-secret \
    --secret-id "${PROJECT_NAME}/${ENVIRONMENT}/argocd/admin-password" \
    --secret-string "${ARGOCD_INITIAL_PASSWORD}" \
    --region "${AWS_REGION}"
}

# ── Phase 11: ArgoCD App of Apps ──────────────────────────────────────────────
configure_argocd_apps() {
  header "Phase 11: ArgoCD App-of-Apps Configuration"

  RDS_ENDPOINT=$(get_output "${STACK_PREFIX}-eks-rds-efs" "RDSClusterEndpoint")
  RDS_READER=$(get_output "${STACK_PREFIX}-eks-rds-efs" "RDSClusterReaderEndpoint")
  COGNITO_POOL_ID=$(get_output "${STACK_PREFIX}-base" "CognitoUserPoolId")
  COGNITO_CLIENT_ID=$(get_output "${STACK_PREFIX}-base" "CognitoUserPoolClientId")
  EFS_FS_ID=$(get_output "${STACK_PREFIX}-eks-rds-efs" "EFSFileSystemId")
  DB_SECRET_ARN=$(get_output "${STACK_PREFIX}-eks-rds-efs" "DBSecretArn")

  # Store config in ConfigMap for ArgoCD apps to reference
  cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: cluster-config
  namespace: argocd
data:
  PROJECT_NAME: "${PROJECT_NAME}"
  ENVIRONMENT: "${ENVIRONMENT}"
  AWS_REGION: "${AWS_REGION}"
  AWS_ACCOUNT_ID: "${AWS_ACCOUNT_ID}"
  DOMAIN_NAME: "${DOMAIN_NAME}"
  RDS_ENDPOINT: "${RDS_ENDPOINT}"
  RDS_READER_ENDPOINT: "${RDS_READER}"
  COGNITO_USER_POOL_ID: "${COGNITO_POOL_ID}"
  COGNITO_CLIENT_ID: "${COGNITO_CLIENT_ID}"
  EFS_FILE_SYSTEM_ID: "${EFS_FS_ID}"
  DB_SECRET_ARN: "${DB_SECRET_ARN}"
  CLUSTER_NAME: "${CLUSTER_NAME}"
EOF

  # ArgoCD App-of-Apps (root app)
  cat <<EOF | kubectl apply -f -
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root
  namespace: argocd
  finalizers:
    - resources-finalizer.argocd.argoproj.io
spec:
  project: default
  source:
    repoURL: ${ARGOCD_REPO_URL}
    targetRevision: HEAD
    path: ${ARGOCD_REPO_PATH}
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
      allowEmpty: false
    syncOptions:
      - CreateNamespace=true
      - PrunePropagationPolicy=foreground
      - PruneLast=true
    retry:
      limit: 5
      backoff:
        duration: 5s
        factor: 2
        maxDuration: 3m
EOF

  log "ArgoCD App-of-Apps configured"
}

# ── Phase 12: Route53 DNS ─────────────────────────────────────────────────────
configure_dns() {
  header "Phase 12: Route53 DNS Records"

  # Wait for ALB to be provisioned by ArgoCD/ALB controller
  info "Waiting for ALB to be provisioned (up to 5 minutes)..."
  local retries=30
  local alb_dns=""
  while [[ $retries -gt 0 && -z "${alb_dns}" ]]; do
    alb_dns=$(kubectl get ingress -n argocd \
      -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    [[ -z "${alb_dns}" ]] && { sleep 10; ((retries--)); }
  done

  if [[ -z "${alb_dns}" ]]; then
    warn "Could not detect ALB DNS. Create Route53 record manually after deployment."
    return
  fi

  # Get ALB Hosted Zone ID (ALB zone IDs by region)
  local alb_zone_id
  case "${AWS_REGION}" in
    ap-northeast-1) alb_zone_id="Z14GRHDCWA56QT" ;;
    us-east-1)      alb_zone_id="Z35SXDOTRQ7X7K" ;;
    us-west-2)      alb_zone_id="Z1H1FL5HABSF5"  ;;
    eu-west-1)      alb_zone_id="Z32O12XQLNTSW2" ;;
    ap-southeast-1) alb_zone_id="Z1LMS91P8CMLE5" ;;
    *)              alb_zone_id="Z14GRHDCWA56QT" ;;
  esac

  cat > /tmp/route53-changes.json <<DNSEOF
{
  "Changes": [
    {
      "Action": "UPSERT",
      "ResourceRecordSet": {
        "Name": "${DOMAIN_NAME}",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "${alb_zone_id}",
          "DNSName": "${alb_dns}",
          "EvaluateTargetHealth": true
        }
      }
    },
    {
      "Action": "UPSERT",
      "ResourceRecordSet": {
        "Name": "*.${DOMAIN_NAME}",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "${alb_zone_id}",
          "DNSName": "${alb_dns}",
          "EvaluateTargetHealth": true
        }
      }
    }
  ]
}
DNSEOF

  aws route53 change-resource-record-sets \
    --hosted-zone-id "${HOSTED_ZONE_ID}" \
    --change-batch file:///tmp/route53-changes.json

  log "Route53 DNS records updated → ${alb_dns}"
}

# ── Phase 13: Pod Identity Associations (App Pods) ───────────────────────────
configure_pod_identities() {
  header "Phase 13: Pod Identity Associations"

  APP_POD_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "AppPodRoleArn")
  EBS_CSI_ROLE_ARN=$(get_output "${STACK_PREFIX}-iam" "EBSCSIDriverRoleArn")

  # Application namespace
  kubectl create namespace app --dry-run=client -o yaml | kubectl apply -f -

  # App pods
  aws eks create-pod-identity-association \
    --cluster-name "${CLUSTER_NAME}" \
    --namespace app \
    --service-account app-sa \
    --role-arn "${APP_POD_ROLE_ARN}" \
    --region "${AWS_REGION}" 2>/dev/null || true

  log "Pod Identity associations configured"
}

# ── Phase 14: Cluster verification ───────────────────────────────────────────
verify_deployment() {
  header "Phase 14: Deployment Verification"

  info "Node status:"
  kubectl get nodes -o wide

  info "\nPod status (all namespaces):"
  kubectl get pods -A

  info "\nStorage classes:"
  kubectl get storageclass

  info "\nKarpenter NodePools:"
  kubectl get nodepools 2>/dev/null || true

  info "\nIngresses:"
  kubectl get ingress -A

  log "Deployment verification complete"
}

# ── Summary ───────────────────────────────────────────────────────────────────
print_summary() {
  header "🎉 Deployment Complete"

  RDS_ENDPOINT=$(get_output "${STACK_PREFIX}-eks-rds-efs" "RDSClusterEndpoint" 2>/dev/null || echo "N/A")
  COGNITO_POOL_ID=$(get_output "${STACK_PREFIX}-base" "CognitoUserPoolId" 2>/dev/null || echo "N/A")

  cat <<SUMMARY
  ┌─────────────────────────────────────────────────────────┐
  │              Infrastructure Summary                      │
  ├─────────────────────────────────────────────────────────┤
  │  Cluster:        ${CLUSTER_NAME}
  │  Region:         ${AWS_REGION}
  │  Account:        ${AWS_ACCOUNT_ID}
  │  Domain:         ${DOMAIN_NAME}
  │  ArgoCD URL:     https://argocd.${DOMAIN_NAME}
  │  RDS Endpoint:   ${RDS_ENDPOINT}
  │  Cognito Pool:   ${COGNITO_POOL_ID}
  ├─────────────────────────────────────────────────────────┤
  │  Next Steps:                                            │
  │  1. Push app manifests to Git repo                      │
  │  2. Configure ArgoCD access (change admin password)     │
  │  3. Apply Karpenter NodePool for your workloads         │
  │  4. Configure application Helm chart values             │
  └─────────────────────────────────────────────────────────┘
SUMMARY
}

# ── Destroy function ──────────────────────────────────────────────────────────
destroy_all() {
  warn "⚠️  DESTROYING ALL RESOURCES - This is irreversible!"
  read -p "Type 'DELETE ${CLUSTER_NAME}' to confirm: " confirm
  [[ "${confirm}" != "DELETE ${CLUSTER_NAME}" ]] && { info "Cancelled."; exit 0; }

  info "Removing Helm releases..."
  helm uninstall argocd -n argocd 2>/dev/null || true
  helm uninstall karpenter -n karpenter 2>/dev/null || true
  helm uninstall aws-load-balancer-controller -n aws-load-balancer 2>/dev/null || true

  info "Deleting CloudFormation stacks (reverse order)..."
  for stack in eks-rds-efs iam security base; do
    aws cloudformation delete-stack \
      --stack-name "${STACK_PREFIX}-${stack}" \
      --region "${AWS_REGION}" 2>/dev/null || true
    aws cloudformation wait stack-delete-complete \
      --stack-name "${STACK_PREFIX}-${stack}" \
      --region "${AWS_REGION}" 2>/dev/null || true
    log "Deleted: ${STACK_PREFIX}-${stack}"
  done
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  local action="${1:-deploy}"

  case "${action}" in
    deploy)
      check_prerequisites
      deploy_base
      deploy_security
      deploy_iam
      deploy_eks_rds_efs
      setup_helm_repos
      deploy_karpenter
      deploy_alb_controller
      deploy_storage_classes
      deploy_metrics_server
      deploy_argocd
      configure_argocd_apps
      configure_pod_identities
      configure_dns
      verify_deployment
      print_summary
      ;;
    destroy)
      destroy_all
      ;;
    verify)
      verify_deployment
      ;;
    dns)
      configure_dns
      ;;
    argocd)
      deploy_argocd
      configure_argocd_apps
      ;;
    karpenter)
      deploy_karpenter
      ;;
    *)
      echo "Usage: $0 {deploy|destroy|verify|dns|argocd|karpenter}"
      echo ""
      echo "Required environment variables:"
      echo "  PROJECT_NAME      - Project name (default: eks-project)"
      echo "  ENVIRONMENT       - Environment (default: prod)"
      echo "  AWS_REGION        - AWS region (default: ap-northeast-1)"
      echo "  DOMAIN_NAME       - Route53 domain (e.g. example.com)"
      echo "  HOSTED_ZONE_ID    - Route53 Hosted Zone ID"
      echo "  ARGOCD_REPO_URL   - Git repository URL for GitOps"
      echo ""
      echo "Example:"
      echo "  export PROJECT_NAME=myapp ENVIRONMENT=prod"
      echo "  export DOMAIN_NAME=myapp.example.com HOSTED_ZONE_ID=Z1234ABCD"
      echo "  export ARGOCD_REPO_URL=https://github.com/org/repo"
      echo "  $0 deploy"
      exit 1
      ;;
  esac
}

main "$@"
