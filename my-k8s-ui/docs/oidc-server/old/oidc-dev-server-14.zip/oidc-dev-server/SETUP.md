# セットアップ手順

初回セットアップで必要な手順をここに集約する。過去の指示で断片的にしか
案内していなかった箇所(.env作成、JWKS生成)を含む。

## 1. 依存関係のインストール

```bash
npm install
npx prisma generate
```

## 2. 環境変数ファイルの作成

`.env.example` は秘密情報を含まないテンプレートであり、これをコピーして
実際の値を設定した `.env` を作成する(`.env` はGit管理対象外)。

```bash
cp .env.example .env
```

`.env` の主要な値:

| 変数 | 説明 | ローカル開発時の例 |
|---|---|---|
| `DATABASE_URL` | SQLiteファイルパス | `file:./dev.db` |
| `OIDC_ISSUER` | Discoveryで公開するissuer URL | `http://localhost:3000` |
| `OIDC_COOKIE_KEYS` | Cookie署名鍵(カンマ区切りで複数可) | ランダムな長い文字列に変更すること |
| `OIDC_JWKS_PATH` | JWKS秘密鍵ファイルの場所 | `./secrets/jwks.json` |
| `ADMIN_JWT_SECRET` | 管理者トークン署名鍵 | ランダムな長い文字列に変更すること |

`OIDC_COOKIE_KEYS` / `ADMIN_JWT_SECRET` は以下のように生成できる:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## 3. JWKS(署名鍵)の生成

`.env` で指定した `OIDC_JWKS_PATH` にJWKS秘密鍵ファイルが存在しないと、
サーバー起動時に読み込みエラーになる。以下のスクリプトで生成する。

```bash
npm run generate:jwks
```

既存ファイルを上書きしたい場合(鍵ローテーション等)は `-- --force` を付ける。

```bash
npm run generate:jwks -- --force
```

## 4. データベースのマイグレーション

```bash
npx prisma migrate dev --name init
```

## 5. 初期データの投入(任意)

React用Public Client、管理者アカウント等を投入する場合:

```bash
SEED_ADMIN_PASSWORD=change-me-please npx prisma db seed
```

## 6. 起動

```bash
npm run dev
```

起動後、以下で疎通確認できる。

```bash
curl http://localhost:3000/.well-known/openid-configuration
```

## つまずきやすいポイント

| 症状 | 原因 | 対処 |
|---|---|---|
| `Environment variable not found: DATABASE_URL`(`prisma migrate`実行時) | `.env` が存在しない、または読み込まれていない | 手順2を実施。カレントディレクトリが `oidc-dev-server` 直下であることを確認 |
| `Invalid environment variables: { ... Required ... }`(`npm run dev`実行時) | `.env`は存在するが、アプリ自体が読み込んでいない(dotenv未使用だった実装不備。現在は修正済み) | 最新版のリポジトリを使用していれば発生しない。発生する場合は`src/config/env.ts`の先頭に`loadDotenv()`呼び出しがあるか確認 |
| `npm run dev` 実行時に `SyntaxError: Unexpected string`(`node_modules/generator-function/require.mjs` 経由) | `oidc-provider → koa → is-generator-function → generator-function` という依存チェーンで、`generator-function@2.0.1` が使う「文字列をexport名に使う」構文(Arbitrary Module Namespace Names)を、tsx内部のesbuildがCJS変換する際に不正なコード(`0 && (module.exports = {"module.exports"})`)を生成してしまう既知のesbuildバグ。**アプリケーションコードの不具合ではない** | `package.json` の `overrides` で `is-generator-function` を `1.0.10`(`generator-function`に依存しない最終バージョン)に固定済み。`npm install` をやり直せば解消する。将来 `koa`/`is-generator-function`/`generator-function`/`esbuild` のいずれかが更新されて根本修正されたら、この`overrides`は削除してよい |
| `ENOENT` でJWKSファイルが読めない | 手順3を実施していない | `npm run generate:jwks` を実行 |
| `enum` 関連の `P1012` エラー | 過去バージョンのschema.prismaを使っている | 本リポジトリの最新版では解消済み(SQLiteはネイティブenum非対応のためString型に変更済み) |
| `prisma generate` がバイナリ取得で失敗する | 社内ネットワーク/プロキシ制限で `binaries.prisma.sh` に到達できない | ネットワーク許可設定を確認するか、`PRISMA_ENGINES_MIRROR` 等の代替ミラー設定を検討 |
