require_relative "boot"

# ----------------------------------------------------------------------------
# `require "rails/all"` ではなく、必要なrailtieのみを明示的にrequireする。
# このアプリの責務は「Access Tokenを検証してJSONを返すこと」のみであり、
# ActiveRecord(DB)、ActionMailer、ActiveStorage、ActionCable等は一切
# 使わない。不要な依存を持ち込まないことは、3年後の保守性レビューで
# 指摘された「本当に必要なものだけを持つ」という原則をこのテストアプリ
# にも適用したもの。
# ----------------------------------------------------------------------------
require "rails"
require "action_controller/railtie"

# dotenv-rails(Gemfile参照)がBundler.require経由で.envを自動読込する。
# [教訓] 別プロジェクト(oidc-dev-server)で.envの読込漏れによる起動失敗が
# あったため、ここでも明示的にコメントで残しておく。
Bundler.require(*Rails.groups)

module RailsTokenVerifier
  class Application < Rails::Application
    config.load_defaults 8.0

    # API専用モード(セッションCookie/ビュー/アセットパイプライン等を持たない)
    config.api_only = true

    # app/services 配下等をオートロード対象に含める
    config.autoload_lib(ignore: %w[assets tasks])

    # このアプリ固有の設定名前空間(config.x.*)。
    # OIDC issuerはCognito移行時にENV変数を切り替えるだけで良い設計とする
    # (config/initializers/oidc.rb 参照)。
    config.x.oidc = ActiveSupport::OrderedOptions.new
  end
end
