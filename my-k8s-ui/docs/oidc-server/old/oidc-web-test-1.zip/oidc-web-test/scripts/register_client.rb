#!/usr/bin/env ruby
# frozen_string_literal: true

require "net/http"
require "json"
require "uri"
require "optparse"

# ----------------------------------------------------------------------------
# oidc-dev-server の Management API を使い、React(Vite)フロントエンド用の
# Public Client(client_secretなし、PKCE必須)を登録するワンショットスクリプト。
#
# 使い方:
#   ruby scripts/register_client.rb \
#     --issuer http://localhost:3000 \
#     --admin-email admin@example.com \
#     --admin-password change-me-please
#
# 事前準備: oidc-dev-server 側で管理者アカウントが作成済みであること
#   (例: SEED_ADMIN_PASSWORD=xxx npx prisma db seed)
# ----------------------------------------------------------------------------

options = {
  issuer: ENV.fetch("OIDC_ISSUER", "http://localhost:3000"),
  client_id: "react-web-test-client",
  redirect_uri: "http://localhost:5173/callback",
  post_logout_redirect_uri: "http://localhost:5173/"
}

OptionParser.new do |opts|
  opts.banner = "Usage: ruby scripts/register_client.rb [options]"
  opts.on("--issuer URL") { |v| options[:issuer] = v }
  opts.on("--admin-email EMAIL") { |v| options[:admin_email] = v }
  opts.on("--admin-password PASSWORD") { |v| options[:admin_password] = v }
  opts.on("--client-id ID") { |v| options[:client_id] = v }
  opts.on("--redirect-uri URI") { |v| options[:redirect_uri] = v }
end.parse!

abort "エラー: --admin-email は必須です" unless options[:admin_email]
abort "エラー: --admin-password は必須です" unless options[:admin_password]

def request_json(method, url, body: nil, headers: {})
  uri = URI.parse(url)
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = uri.scheme == "https"

  request = method.new(uri)
  request["Content-Type"] = "application/json"
  headers.each { |k, v| request[k] = v }
  request.body = JSON.generate(body) if body

  response = http.request(request)
  parsed = response.body.to_s.empty? ? {} : JSON.parse(response.body)
  [response, parsed]
end

puts "管理者ログイン中... (#{options[:issuer]}/api/v1/auth/login)"

login_response, login_body = request_json(
  Net::HTTP::Post,
  "#{options[:issuer]}/api/v1/auth/login",
  body: { email: options[:admin_email], password: options[:admin_password] }
)

abort "管理者ログインに失敗しました (#{login_response.code}): #{login_body}" unless login_response.code.to_i == 200

access_token = login_body.fetch("accessToken")
puts "管理者ログイン成功。"

client_payload = {
  clientId: options[:client_id],
  isPublic: true,
  tokenEndpointAuthMethod: "NONE",
  redirectUris: [options[:redirect_uri]],
  postLogoutRedirectUris: [options[:post_logout_redirect_uri]],
  allowedScopes: %w[openid email profile offline_access groups],
  grantTypes: %w[authorization_code refresh_token]
}

puts "Client '#{options[:client_id]}' (Public Client) を登録中..."

client_response, client_body = request_json(
  Net::HTTP::Post,
  "#{options[:issuer]}/api/v1/clients",
  body: client_payload,
  headers: { "Authorization" => "Bearer #{access_token}" }
)

case client_response.code.to_i
when 201
  puts ""
  puts "登録成功。frontend/.env の以下を確認してください(通常はデフォルト値のままでよい):"
  puts ""
  puts "VITE_OIDC_ISSUER=#{options[:issuer]}"
  puts "VITE_OIDC_CLIENT_ID=#{client_body.fetch('clientId')}"
  puts "VITE_OIDC_REDIRECT_URI=#{options[:redirect_uri]}"
when 409
  puts "Client '#{options[:client_id]}' は既に登録済みです(スキップ)。"
else
  abort "Client登録に失敗しました (#{client_response.code}): #{client_body}"
end
