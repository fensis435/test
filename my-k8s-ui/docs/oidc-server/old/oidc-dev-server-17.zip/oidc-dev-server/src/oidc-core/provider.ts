import { readFileSync } from "node:fs";
import Provider from "oidc-provider";
import { env } from "../config/env.js";
import { PrismaOidcAdapter } from "./adapter.js";
import { claimsConfig, scopesSupported, findAccount, extraAccessTokenClaims } from "./claims.js";

// ----------------------------------------------------------------------------
// oidc-provider 設定方針(前回設計のoidc-provider設定方針節を忠実に反映)
//
//   - features.devInteractions: 無効化(独自ログイン画面を使用)
//   - features.revocation: 有効化(RFC 7009)
//   - features.introspection: 有効化(RFC 7662)
//     [修正: レビュー指摘#3] Access TokenをJWT化するため必須ではないが、
//     Confidential Client(Rails BFF等)がAccess Tokenの失効状態を
//     JWKS検証だけでは判定できない(失効済みでもJWT自体は有効に見える)
//     ため、多層防御として有効化する。
//   - features.rpInitiatedLogout: 有効化(標準Logout。Cognitoとの差異は
//     Reactラッパー側で吸収する設計のため、ここは標準のまま)
//   - PKCE: 全クライアントで必須
//   - Cognito固有のクレーム名・スコープ・パラメータは一切定義しない
//
// [修正: レビュー指摘#3] formats.AccessToken を "jwt" に明示。
//   以前の実装はoidc-providerのデフォルト(opaque)のままであり、
//   Railsが「JWKS URIベースでJWT検証する」という確定済み設計と矛盾していた。
//   JWT化することで、Railsは/introspectを呼ばずにJWKSのみでAccess Token
//   の署名・有効期限を検証できる(Cognitoが発行するAccess Tokenも同様に
//   JWT形式であるため、本番との形式パリティも同時に確保される)。
//
// [修正: レビュー指摘#4] clientBasedCORS を追加。
//   React(Vite: 別オリジン)からのブラウザfetchが/token・/userinfoに対して
//   CORSでブロックされていた問題に対応。登録済みClientのredirectUrisの
//   オリジンをそのまま許可オリジンとして扱う(Client登録と一致させることで
//   個別のCORS許可リスト管理を不要にする設計)。
// ----------------------------------------------------------------------------

function loadJwks(): { keys: unknown[] } {
  const raw = readFileSync(env.OIDC_JWKS_PATH, "utf-8");
  return JSON.parse(raw) as { keys: unknown[] };
}

function originFromUri(uri: string): string | null {
  try {
    return new URL(uri).origin;
  } catch {
    return null;
  }
}

export function createOidcProvider(): Provider {
  const jwks = loadJwks();

  const provider = new Provider(env.OIDC_ISSUER, {
    adapter: PrismaOidcAdapter,
    jwks,

    findAccount,

    claims: claimsConfig,
    scopes: [...scopesSupported],

    cookies: {
      keys: env.OIDC_COOKIE_KEYS_ARRAY,
      long: { signed: true, sameSite: "lax" },
      short: { signed: true, sameSite: "lax" },
    },

    features: {
      devInteractions: { enabled: false },
      revocation: { enabled: true },
      introspection: { enabled: true },
      rpInitiatedLogout: { enabled: true },
      userinfo: { enabled: true },
      resourceIndicators: { enabled: false },
    },

    // [修正: レビュー指摘#3] Access TokenをJWT形式で発行する。
    formats: {
      AccessToken: "jwt",
    },

    pkce: {
      required: () => true,
      methods: ["S256"],
    },

    responseTypes: ["code"],

    tokenEndpointAuthMethods: ["none", "client_secret_basic"],

    ttl: {
      AuthorizationCode: 60, // 秒。短命。
      AccessToken: 3600, // 1時間。Cognitoデフォルト相当。
      IdToken: 3600,
      RefreshToken: 2592000, // 30日。Cognitoデフォルト相当。
      Session: 1209600, // 14日。
      Interaction: 3600,
      Grant: 2592000,
    },

    // [注記] oidc-provider の configuration オブジェクトは
    // Record<string, unknown> としてしか型付けできない(src/types/oidc-provider.d.ts
    // 参照)ため、以下の各コールバックの引数はコンテキスト型推論が効かない。
    // 正直に `any` として明示する(実際の形はoidc-providerのドキュメントに
    // 依拠しており、型システムでは保証できないことを隠さないため)。
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    extraTokenClaims: async (_ctx: any, token: any) => {
      if (token.kind === "AccessToken") {
        return extraAccessTokenClaims();
      }
      return {};
    },

    interactions: {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      url: (_ctx: any, interaction: any) => `/interaction/${interaction.uid}`,
    },

    routes: {
      authorization: "/authorize",
      token: "/token",
      userinfo: "/userinfo",
      jwks: "/jwks.json",
      revocation: "/revoke",
      introspection: "/introspect",
      end_session: "/logout",
    },

    // [修正: レビュー指摘#4]
    // 登録済みClientのredirectUris/postLogoutRedirectUrisのオリジンのみを許可する。
    // 未登録オリジンからのCORSは拒否することで、Client登録台帳がそのまま
    // CORS許可リストとしても機能する(二重管理を避ける設計)。
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    clientBasedCORS: (_ctx: any, origin: string, client: any) => {
      const allowedOrigins = new Set<string>();
      for (const uri of client.redirectUris ?? []) {
        const o = originFromUri(uri);
        if (o) allowedOrigins.add(o);
      }
      for (const uri of client.postLogoutRedirectUris ?? []) {
        const o = originFromUri(uri);
        if (o) allowedOrigins.add(o);
      }
      return allowedOrigins.has(origin);
    },

    // [修正] oidc-provider起動時のNOTICE
    // ("default renderError function called, you SHOULD change it")に対応。
    // デフォルトのエラー画面は詳細を一切表示しないため、原因調査に
    // 非常に時間がかかっていた。開発環境では実際のエラー内容を画面にも
    // 出すことで、以後のデバッグを大幅に短縮する。
    // 本番相当環境で使う場合は、ここをスタックトレース非表示の
    // ユーザー向け文言に差し替えること。
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    renderError: async (ctx: any, out: any, error: any) => {
      // eslint-disable-next-line no-console
      console.error("[oidc-provider] renderError:", error);
      ctx.type = "html";
      ctx.body = `<!DOCTYPE html>
<html lang="ja">
<head><meta charset="utf-8"><title>OIDC Error</title></head>
<body>
  <h1>oidc-provider error</h1>
  <pre>${escapeHtml(JSON.stringify(out, null, 2))}</pre>
  <p style="color:#888;font-size:0.85rem;">
    開発環境向けの詳細表示です。本番相当環境ではこの内容を表示しないよう
    src/oidc-core/provider.ts の renderError を差し替えてください。
  </p>
</body>
</html>`;
    },
  });

  // renderErrorだけでは拾えない、5xx相当のサーバー内部エラーの詳細
  // (スタックトレース含む)をログに出す。renderErrorのoutにはエラーの
  // 概要しか含まれないため、実際のデバッグにはこちらのログが必要になる。
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  provider.on("server_error", (_ctx: any, err: any) => {
    // eslint-disable-next-line no-console
    console.error("[oidc-provider] server_error:", err);
  });

  return provider;
}

function escapeHtml(value: string): string {
  return value.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string
  );
}
