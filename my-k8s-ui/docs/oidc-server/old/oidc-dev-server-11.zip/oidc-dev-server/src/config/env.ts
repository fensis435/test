import { z } from "zod";

// ----------------------------------------------------------------------------
// 環境変数のバリデーションと型付きアクセスを一元化する。
// OIDC_ISSUER を切り替えるだけで本番Cognito Issuerへの移行が可能な設計。
// ----------------------------------------------------------------------------

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(3000),

  OIDC_ISSUER: z.string().url(),
  OIDC_COOKIE_KEYS: z.string().min(1),
  OIDC_JWKS_PATH: z.string().min(1),

  DATABASE_URL: z.string().min(1),

  ADMIN_JWT_SECRET: z.string().min(16),
  ADMIN_JWT_TTL_SECONDS: z.coerce.number().int().positive().default(3600),

  WEBHOOK_MAX_ATTEMPTS: z.coerce.number().int().positive().default(5),
  WEBHOOK_RETRY_BASE_DELAY_MS: z.coerce.number().int().positive().default(2000),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error("Invalid environment variables:", parsed.error.flatten().fieldErrors);
  throw new Error("Environment variable validation failed. See stderr for details.");
}

export const env = {
  ...parsed.data,
  OIDC_COOKIE_KEYS_ARRAY: parsed.data.OIDC_COOKIE_KEYS.split(",").map((s) => s.trim()),
};
