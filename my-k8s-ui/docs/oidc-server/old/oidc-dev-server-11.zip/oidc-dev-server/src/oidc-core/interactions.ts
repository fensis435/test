import { Router } from "express";
import type Provider from "oidc-provider";
import argon2 from "argon2";
import { prisma } from "../infra/persistence/prisma-client.js";

// ----------------------------------------------------------------------------
// oidc-provider の features.devInteractions は無効化し、
// 独自のログイン/Consent画面をここで実装する。
// Consentは1st-party Reactクライアントに対してはスキップする方針
// (Client.skipConsent相当のフラグをallowedScopesに含めて判定)。
// ----------------------------------------------------------------------------

export function buildInteractionsRouter(provider: Provider): Router {
  const router = Router();

  router.get("/interaction/:uid", async (req, res, next) => {
    try {
      const { uid, prompt, params } = await provider.interactionDetails(req, res);

      if (prompt.name === "login") {
        res.type("html").send(renderLoginPage(uid, params.client_id as string, null));
        return;
      }

      if (prompt.name === "consent") {
        // 1st-party クライアントは Consent をスキップして即許可する。
        const grant = new (provider.Grant as unknown as new (opts: { accountId: string; clientId: string }) => any)({
          accountId: prompt.details.accountId as string,
          clientId: params.client_id as string,
        });
        grant.addOIDCScope(String(params.scope ?? ""));
        const grantId = await grant.save();

        const result = { consent: { grantId } };
        await provider.interactionFinished(req, res, result, { mergeWithLastSubmission: true });
        return;
      }

      next(new Error(`Unsupported interaction prompt: ${prompt.name}`));
    } catch (err) {
      next(err);
    }
  });

  router.post("/interaction/:uid/login", async (req, res, next) => {
    try {
      const { uid } = req.params;
      const { email, password } = req.body as { email?: string; password?: string };

      if (!email || !password) {
        res.type("html").status(400).send(renderLoginPage(uid, "", "メールアドレスとパスワードを入力してください。"));
        return;
      }

      const normalizedEmail = email.trim().toLowerCase();
      const user = await prisma.user.findFirst({ where: { normalizedEmail, deletedAt: null } });

      if (!user || user.status !== "ACTIVE") {
        res.type("html").status(401).send(renderLoginPage(uid, "", "認証に失敗しました。"));
        return;
      }

      const passwordValid = await argon2.verify(user.passwordHash, password);
      if (!passwordValid) {
        res.type("html").status(401).send(renderLoginPage(uid, "", "認証に失敗しました。"));
        return;
      }

      const result = {
        login: { accountId: user.id },
      };

      await provider.interactionFinished(req, res, result, { mergeWithLastSubmission: false });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

function renderLoginPage(uid: string, _clientId: string, errorMessage: string | null): string {
  return `<!DOCTYPE html>
<html lang="ja">
<head><meta charset="utf-8"><title>Sign in</title></head>
<body>
  <h1>Sign in</h1>
  ${errorMessage ? `<p style="color:red;">${escapeHtml(errorMessage)}</p>` : ""}
  <form method="post" action="/interaction/${encodeURIComponent(uid)}/login">
    <label>Email <input type="email" name="email" required /></label><br/>
    <label>Password <input type="password" name="password" required /></label><br/>
    <button type="submit">Sign in</button>
  </form>
</body>
</html>`;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] as string));
}
