# OIDC Test Client (Ruby)

`oidc-dev-server` の動作確認用に作られた、最小構成のOIDCクライアント(RP)です。
Authorization Code + PKCE、ID Token/Access TokenのJWT署名検証、UserInfo、
Refresh Token、Introspection、Revocation、RP-Initiated Logoutまで一通り
試せます。

**このアプリが利用するのは標準OIDCエンドポイントのみ**(`/authorize`,
`/token`, `/userinfo`, `/jwks.json`, `/logout`, `/revoke`, `/introspect`)
です。`oidc-dev-server`のManagement API(`/api/v1/*`)には、クライアント
登録用の`scripts/register_client.rb`からのみアクセスします。これは
Reactが守るべき境界と同じものを、Rubyクライアントの立場からも検証する
意図的な設計です。

## 前提

- Ruby 3.4.5
- `oidc-dev-server` がローカルで起動していること(デフォルト `http://localhost:3000`)
- `oidc-dev-server` 側に管理者アカウントが作成済みであること

  ```bash
  # oidc-dev-server 側で実行
  SEED_ADMIN_EMAIL=admin@example.com SEED_ADMIN_PASSWORD=change-me-please npx prisma db seed
  ```

## セットアップ

### 1. 依存関係のインストール

```bash
bundle install
```

### 2. `.env` の作成

```bash
cp .env.example .env
```

### 3. OAuth Clientの登録

`oidc-dev-server`のManagement APIを使って、このアプリ用のClientを自動登録します。

```bash
ruby scripts/register_client.rb \
  --issuer http://localhost:3000 \
  --admin-email admin@example.com \
  --admin-password change-me-please
```

実行すると`OIDC_CLIENT_ID` / `OIDC_CLIENT_SECRET`が出力されるので、`.env`に反映してください。

デフォルトではConfidential Client(`client_secret_basic` + PKCE)として登録します。
Public Client(PKCEのみ)として試したい場合は `--public` を付けてください。
その場合`.env`の`OIDC_CLIENT_SECRET`は空のままにしてください。

### 4. 起動

```bash
bundle exec rackup config.ru -p 4567
```

または:

```bash
bundle exec puma -p 4567
```

`http://localhost:4567` にアクセスすると「ログイン」ボタンが表示されます。

## 動作確認できる項目

| 画面操作 | 検証内容 |
|---|---|
| ログイン | Authorization Code + PKCE(S256)の一連のフロー |
| コールバック後の表示 | ID Tokenの署名検証(`iss`/`aud`/`nonce`含む)、Access TokenがJWT形式で発行されていることの検証 |
| UserInfoを呼ぶ | `/userinfo`エンドポイントの疎通 |
| Introspectionを呼ぶ | `/introspect`エンドポイント(RFC 7662)の疎通 |
| Refresh Tokenで更新 | Refresh Tokenローテーションの動作確認 |
| Access Tokenを失効 | `/revoke`エンドポイント(RFC 7009)の疎通 |
| ログアウト | RP-Initiated Logout(標準OIDC Logout)の疎通 |

## Cognito移行時の位置づけ

このアプリの`lib/oidc_discovery.rb`はissuer以外の個々のURLをハードコード
しておらず、`.env`の`OIDC_ISSUER`をCognito User PoolのURLに差し替える
だけで、Discovery経由で全エンドポイントを再解決します。

唯一の例外は`app.rb`の`get "/logout"`です。CognitoのRP-Initiated Logoutは
標準(`id_token_hint` + `post_logout_redirect_uri`)ではなく独自パラメータ
(`client_id` + `logout_uri`)を使うため、Cognito切替時はこのメソッドの
中身だけを差し替える必要があります(Reactアプリ側で提案した「ログアウト
ラッパー」と同じ設計判断です)。
