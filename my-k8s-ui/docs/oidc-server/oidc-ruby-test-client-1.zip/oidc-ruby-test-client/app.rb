# frozen_string_literal: true

require "sinatra/base"
require "dotenv/load"
require "securerandom"
require "uri"
require "json"

require_relative "lib/oidc_discovery"
require_relative "lib/pkce"
require_relative "lib/token_client"
require_relative "lib/jwt_verifier"

# ----------------------------------------------------------------------------
# oidc-dev-server の動作確認用OIDCクライアント(テストアプリ)。
#
# このアプリが叩くのは標準OIDCエンドポイントのみ(/authorize, /token,
# /userinfo, /jwks.json, /logout, /revoke, /introspect)であり、
# Management API(/api/v1/*)には一切アクセスしない。
# これはReact側が守るべき境界と同じものを、Rubyクライアントの立場からも
# 検証するための意図的な設計。
# ----------------------------------------------------------------------------

class OidcTestClientApp < Sinatra::Base
  ISSUER = ENV.fetch("OIDC_ISSUER", "http://localhost:3000")
  CLIENT_ID = ENV.fetch("OIDC_CLIENT_ID", "ruby-test-client")
  CLIENT_SECRET = ENV["OIDC_CLIENT_SECRET"] # 未設定ならpublic clientとして振る舞う
  REDIRECT_URI = ENV.fetch("OIDC_REDIRECT_URI", "http://localhost:4567/callback")
  POST_LOGOUT_REDIRECT_URI = ENV.fetch("OIDC_POST_LOGOUT_REDIRECT_URI", "http://localhost:4567/")
  SCOPES = ENV.fetch("OIDC_SCOPES", "openid email profile groups offline_access")

  configure do
    set :sessions, true
    set :session_secret, ENV["SESSION_SECRET"].to_s.empty? ? SecureRandom.hex(32) : ENV["SESSION_SECRET"]
    set :views, File.join(__dir__, "views")
    set :bind, ENV.fetch("BIND", "0.0.0.0")
    set :port, ENV.fetch("PORT", 4567).to_i

    discovery = OidcDiscovery.new(ISSUER)
    set :discovery, discovery
    set :token_client, TokenClient.new(
      discovery: discovery,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri: REDIRECT_URI
    )
    set :jwt_verifier, JwtVerifier.new(discovery: discovery)
  end

  # --------------------------------------------------------------------------
  # トップページ: ログイン状態と、取得済みトークン/クレームの表示
  # --------------------------------------------------------------------------
  get "/" do
    erb :index, locals: {
      tokens: session[:tokens],
      id_claims: session[:id_token_claims],
      access_claims: session[:access_token_claims],
      client_id: CLIENT_ID,
      is_public_client: CLIENT_SECRET.to_s.empty?,
      error: session.delete(:flash_error)
    }
  end

  # --------------------------------------------------------------------------
  # ログイン開始: PKCE生成 -> Authorization Endpointへリダイレクト
  # --------------------------------------------------------------------------
  get "/login" do
    verifier = Pkce.generate_verifier
    challenge = Pkce.challenge_for(verifier)
    state = SecureRandom.hex(16)
    nonce = SecureRandom.hex(16)

    session[:pkce_verifier] = verifier
    session[:oauth_state] = state
    session[:oauth_nonce] = nonce

    begin
      query = URI.encode_www_form(
        response_type: "code",
        client_id: CLIENT_ID,
        redirect_uri: REDIRECT_URI,
        scope: SCOPES,
        state: state,
        nonce: nonce,
        code_challenge: challenge,
        code_challenge_method: "S256"
      )

      redirect "#{settings.discovery.authorization_endpoint}?#{query}"
    rescue OidcDiscovery::Error => e
      session[:flash_error] = "Discoveryドキュメントの取得に失敗しました: #{e.message}"
      redirect "/"
    end
  end

  # --------------------------------------------------------------------------
  # コールバック: 認可コードをトークンに交換し、ID Token/Access Tokenを検証
  # --------------------------------------------------------------------------
  get "/callback" do
    if params["error"]
      session[:flash_error] = "認可サーバーがエラーを返却: #{params['error']} - #{params['error_description']}"
      redirect "/"
    end

    if params["state"].nil? || params["state"] != session[:oauth_state]
      halt 400, erb(:error, locals: { message: "state不一致(CSRF対策)。ログインをやり直してください。" })
    end

    begin
      tokens = settings.token_client.exchange_code(
        code: params["code"],
        code_verifier: session[:pkce_verifier]
      )

      id_claims, = settings.jwt_verifier.verify(
        tokens.fetch("id_token"),
        expected_audience: CLIENT_ID,
        expected_nonce: session[:oauth_nonce]
      )

      # Access TokenはJWT形式で発行される設計(formats.AccessToken = "jwt")。
      # 検証に失敗した場合は「opaqueに戻っていないか」の regression 検知として
      # エラー内容をそのまま画面に表示する。
      access_claims =
        begin
          claims, = settings.jwt_verifier.verify(tokens.fetch("access_token"))
          claims
        rescue JWT::DecodeError => e
          { "_verification_error" => "Access Tokenの検証に失敗しました(JWT形式でない可能性があります): #{e.message}" }
        end

      session[:tokens] = tokens
      session[:id_token_claims] = id_claims
      session[:access_token_claims] = access_claims
    rescue TokenClient::Error, JWT::DecodeError, OidcDiscovery::Error => e
      session[:flash_error] = e.message
    ensure
      session.delete(:pkce_verifier)
      session.delete(:oauth_state)
      session.delete(:oauth_nonce)
    end

    redirect "/"
  end

  # --------------------------------------------------------------------------
  # UserInfoエンドポイントの疎通確認
  # --------------------------------------------------------------------------
  get "/userinfo" do
    halt 401, "not logged in" unless session[:tokens]

    begin
      result = settings.token_client.userinfo(access_token: session[:tokens]["access_token"])
      erb :json_result, locals: { title: "UserInfo", result: result }
    rescue TokenClient::Error, OidcDiscovery::Error => e
      erb :error, locals: { message: e.message }
    end
  end

  # --------------------------------------------------------------------------
  # Refresh Tokenによるトークン更新(ローテーション動作の確認)
  # --------------------------------------------------------------------------
  get "/refresh" do
    refresh_token = session[:tokens] && session[:tokens]["refresh_token"]
    halt 401, "no refresh_token in session (offline_access scopeでログインしてください)" unless refresh_token

    begin
      tokens = settings.token_client.refresh(refresh_token: refresh_token)
      session[:tokens] = tokens

      if tokens["id_token"]
        id_claims, = settings.jwt_verifier.verify(tokens["id_token"], expected_audience: CLIENT_ID)
        session[:id_token_claims] = id_claims
      end

      if tokens["access_token"]
        access_claims, = settings.jwt_verifier.verify(tokens["access_token"])
        session[:access_token_claims] = access_claims
      end
    rescue TokenClient::Error, JWT::DecodeError, OidcDiscovery::Error => e
      session[:flash_error] = "Refresh失敗: #{e.message}"
    end

    redirect "/"
  end

  # --------------------------------------------------------------------------
  # Introspectionエンドポイントの疎通確認(RFC 7662)
  # --------------------------------------------------------------------------
  get "/introspect" do
    halt 401, "not logged in" unless session[:tokens]

    begin
      result = settings.token_client.introspect(token: session[:tokens]["access_token"])
      erb :json_result, locals: { title: "Introspection", result: result }
    rescue TokenClient::Error, OidcDiscovery::Error => e
      erb :error, locals: { message: e.message }
    end
  end

  # --------------------------------------------------------------------------
  # Access Tokenの明示的な失効(RFC 7009)
  # --------------------------------------------------------------------------
  post "/revoke" do
    halt 401, "not logged in" unless session[:tokens]

    begin
      settings.token_client.revoke(token: session[:tokens]["access_token"], token_type_hint: "access_token")
      session[:flash_error] = "Access Tokenを失効させました(セッション上のトークンはまだ表示されていますが、以後APIコールは401になります)"
    rescue TokenClient::Error, OidcDiscovery::Error => e
      session[:flash_error] = "Revoke失敗: #{e.message}"
    end

    redirect "/"
  end

  # --------------------------------------------------------------------------
  # RP-Initiated Logout(標準OIDC Logout)
  # 重要: Cognito本番ではこのエンドポイントの挙動が非標準になる
  # (id_token_hintベースではなくclient_id/logout_uriを使う)ため、
  # このメソッド自体がReact側で言う「ラッパー」の役割を果たしている。
  # --------------------------------------------------------------------------
  get "/logout" do
    id_token_hint = session[:tokens] && session[:tokens]["id_token"]
    session.clear

    if id_token_hint
      query = URI.encode_www_form(
        id_token_hint: id_token_hint,
        post_logout_redirect_uri: POST_LOGOUT_REDIRECT_URI
      )
      redirect "#{settings.discovery.end_session_endpoint}?#{query}"
    else
      redirect "/"
    end
  end
end
