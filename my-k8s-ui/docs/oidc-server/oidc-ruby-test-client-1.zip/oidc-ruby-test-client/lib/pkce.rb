# frozen_string_literal: true

require "securerandom"
require "digest"
require "base64"

# ----------------------------------------------------------------------------
# RFC 7636 (PKCE) の code_verifier / code_challenge を生成する。
# oidc-dev-server 側は S256 のみを許容する設計(前回設計で確定済み)のため、
# ここでも S256 のみをサポートし、plain は実装しない。
# ----------------------------------------------------------------------------

module Pkce
  # RFC 7636 4.1: code_verifier は 43〜128 文字の [A-Z] / [a-z] / [0-9] / "-" / "." / "_" / "~"
  # SecureRandom.urlsafe_base64(64) は約86文字のURL-safe文字列を生成し、この範囲に収まる。
  def self.generate_verifier
    SecureRandom.urlsafe_base64(64)
  end

  # RFC 7636 4.2: code_challenge = BASE64URL-ENCODE(SHA256(ASCII(code_verifier)))
  def self.challenge_for(verifier)
    digest = Digest::SHA256.digest(verifier)
    Base64.urlsafe_encode64(digest, padding: false)
  end
end
