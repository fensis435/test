# frozen_string_literal: true

require "net/http"
require "json"
require "uri"
require "timeout"

# ----------------------------------------------------------------------------
# OIDC Discoveryドキュメント(/.well-known/openid-configuration)とJWKSの取得。
#
# 設計上の重要な点: このクラスは issuer の値だけを知っており、
# authorize/token/jwks等の個々のURLは一切ハードコードしていない。
# これはReact側のoidc-client-tsが行っているのと同じ設計であり、
# 「Cognito切替時にissuerを変えるだけでよい」という最優先要件を
# Rubyクライアント側でも体現するための実装方針。
# ----------------------------------------------------------------------------

class OidcDiscovery
  class Error < StandardError; end

  def initialize(issuer)
    @issuer = issuer.to_s.chomp("/")
    @document = nil
    @jwks = nil
  end

  def document
    @document ||= fetch_json("#{@issuer}/.well-known/openid-configuration")
  end

  # JWKSは鍵ローテーションに追従できるよう、明示的に再取得できるようにする。
  def jwks(force_refresh: false)
    @jwks = nil if force_refresh
    @jwks ||= fetch_json(document.fetch("jwks_uri"))
  end

  def issuer = document.fetch("issuer")
  def authorization_endpoint = document.fetch("authorization_endpoint")
  def token_endpoint = document.fetch("token_endpoint")
  def userinfo_endpoint = document.fetch("userinfo_endpoint")
  def end_session_endpoint = document.fetch("end_session_endpoint")
  def revocation_endpoint = document.fetch("revocation_endpoint")
  def introspection_endpoint = document.fetch("introspection_endpoint")

  private

  def fetch_json(url)
    uri = URI.parse(url)
    response = Net::HTTP.get_response(uri)

    unless response.is_a?(Net::HTTPSuccess)
      raise Error, "GET #{url} failed: #{response.code} #{response.body}"
    end

    JSON.parse(response.body)
  rescue JSON::ParserError => e
    raise Error, "GET #{url} returned invalid JSON: #{e.message}"
  rescue Errno::ECONNREFUSED, Errno::ETIMEDOUT, SocketError, Timeout::Error => e
    raise Error, "GET #{url} failed to connect (#{e.class}). oidc-dev-server が起動しているか確認してください。"
  end
end
