# frozen_string_literal: true

require "net/http"
require "json"
require "uri"

# ----------------------------------------------------------------------------
# oidc-dev-server の標準OIDCエンドポイント(token/userinfo/revoke/introspect)
# に対するクライアント。Management API(/api/v1/*)には一切アクセスしない
# ——このRubyアプリはCognito本番でも同じ形で動くべき「Reactと同格の
# OIDCクライアント」の立ち位置を意図的にとっている。
#
# client_secretが与えられた場合はHTTP Basic認証(client_secret_basic)、
# 与えられない場合はPublicクライアント(PKCEのみ)として振る舞う。
# oidc-dev-server側はどちらの場合もPKCE必須(前回設計で確定)のため、
# code_verifierは常に必須。
# ----------------------------------------------------------------------------

class TokenClient
  class Error < StandardError; end

  def initialize(discovery:, client_id:, redirect_uri:, client_secret: nil)
    @discovery = discovery
    @client_id = client_id
    @client_secret = client_secret
    @redirect_uri = redirect_uri
  end

  def exchange_code(code:, code_verifier:)
    post_token(
      grant_type: "authorization_code",
      code: code,
      redirect_uri: @redirect_uri,
      code_verifier: code_verifier
    )
  end

  def refresh(refresh_token:)
    post_token(
      grant_type: "refresh_token",
      refresh_token: refresh_token
    )
  end

  def userinfo(access_token:)
    uri = URI.parse(@discovery.userinfo_endpoint)
    request = Net::HTTP::Get.new(uri)
    request["Authorization"] = "Bearer #{access_token}"

    parse_json_response(http_for(uri).request(request))
  end

  def revoke(token:, token_type_hint: "refresh_token")
    post_form(@discovery.revocation_endpoint, token: token, token_type_hint: token_type_hint)
  end

  def introspect(token:)
    post_form(@discovery.introspection_endpoint, token: token)
  end

  private

  def post_token(params)
    post_form(@discovery.token_endpoint, params.merge(client_id: @client_id))
  end

  def post_form(url, params)
    uri = URI.parse(url)
    request = Net::HTTP::Post.new(uri)
    request.set_form_data(params)
    apply_client_auth(request)

    parse_json_response(http_for(uri).request(request))
  end

  def apply_client_auth(request)
    return if @client_secret.nil? || @client_secret.empty?

    # tokenEndpointAuthMethod: CLIENT_SECRET_BASIC で登録したClientに対応。
    request.basic_auth(@client_id, @client_secret)
  end

  def http_for(uri)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = uri.scheme == "https"
    http
  end

  def parse_json_response(response)
    body = response.body.to_s
    parsed = body.empty? ? {} : JSON.parse(body)

    unless response.is_a?(Net::HTTPSuccess)
      detail = parsed["error_description"] || parsed["error"] || body
      raise Error, "#{response.code} #{response.message}: #{detail}"
    end

    parsed
  rescue JSON::ParserError
    raise Error, "Invalid JSON response (status #{response.code}): #{body}"
  end
end
