# frozen_string_literal: true

require "jwt"

# ----------------------------------------------------------------------------
# ID Token および Access Token(JWT形式)の署名検証。
#
# oidc-dev-server は formats.AccessToken = "jwt" を設定しているため、
# Access TokenもID Tokenと同じJWKSで検証できる(Cognitoも同様にAccess
# TokenをJWT形式で発行するため、本番との形式パリティを確認する意味も持つ)。
#
# 鍵ローテーションへの対応: JWT::JWK::Set の kid_not_found コールバックで
# JWKSを一度だけ再取得し、未知のkidによる検証失敗を吸収する。
# ----------------------------------------------------------------------------

class JwtVerifier
  def initialize(discovery:)
    @discovery = discovery
  end

  # @return [Array(Hash, Hash)] [payload, header]
  def verify(token, expected_audience: nil, expected_nonce: nil)
    payload, header = JWT.decode(
      token,
      nil,
      true,
      algorithms: ["RS256"],
      jwks: jwks_loader,
      verify_iss: true,
      iss: @discovery.issuer,
      verify_aud: !expected_audience.nil?,
      aud: expected_audience
    )

    if expected_nonce && payload["nonce"] != expected_nonce
      raise JWT::DecodeError, "nonce mismatch (possible replay attack)"
    end

    [payload, header]
  end

  private

  def jwks_loader
    lambda do |options|
      jwks_hash = @discovery.jwks(force_refresh: options[:kid_not_found] == true)
      JWT::JWK::Set.new(jwks_hash)
    end
  end
end
