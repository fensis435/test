#!/usr/bin/env ruby
# frozen_string_literal: true

require "net/http"
require "json"
require "uri"
require "optparse"

# ----------------------------------------------------------------------------
# oidc-dev-server の Management API (/api/v1/auth/login, /api/v1/clients) を
# 使って、このRubyテストクライアント用のOAuth Clientを登録するワンショット
# スクリプト。
#
# このスクリプトが叩くのはManagement APIのみであり、標準OIDCエンドポイント
# には触れない(app.rb側との役割分担を明確にするため)。
#
# 使い方:
#   ruby scripts/register_client.rb \
#     --issuer http://localhost:3000 \
#     --admin-email admin@example.com \
#     --admin-password change-me-please
#
# 事前準備: oidc-dev-server 側で管理者アカウントが作成済みであること
#   (例: SEED_ADMIN_PASSWORD=xxx npx prisma db seed)
#
# [修正の経緯]
#   1. `--post-logout-redirect-uri` を指定するCLIオプションが存在せず、
#      `postLogoutRedirectUris` が常に既定値のままハードコードされていた。
#      `--redirect-uri` を独自ドメインに変更してもpostLogoutRedirectUris
#      だけ食い違ったままになり、別途手動でPATCHする必要があった。
#   2. Clientが既に登録済み(409)の場合、何も更新せず単にスキップしていた。
#      `--update` フラグで既存Clientの更新(PATCH)にも対応させた
#      (confidential clientの場合、clientSecretはPATCHでは変更されない
#      ため、シークレットのローテーションは引き続き別途 secret/rotate を使うこと)。
# ----------------------------------------------------------------------------

options = {
  issuer: ENV.fetch("OIDC_ISSUER", "http://localhost:3000"),
  client_id: "ruby-test-client",
  redirect_uri: "http://localhost:4567/callback",
  post_logout_redirect_uri: "http://localhost:4567/",
  confidential: true,
  update: false
}

OptionParser.new do |opts|
  opts.banner = "Usage: ruby scripts/register_client.rb [options]"
  opts.on("--issuer URL", "oidc-dev-server のissuer URL") { |v| options[:issuer] = v }
  opts.on("--admin-email EMAIL", "管理者アカウントのメールアドレス") { |v| options[:admin_email] = v }
  opts.on("--admin-password PASSWORD", "管理者アカウントのパスワード") { |v| options[:admin_password] = v }
  opts.on("--client-id ID", "登録するclient_id(デフォルト: ruby-test-client)") { |v| options[:client_id] = v }
  opts.on("--redirect-uri URI", "コールバックURL") { |v| options[:redirect_uri] = v }
  opts.on("--post-logout-redirect-uri URI", "ログアウト後のリダイレクト先URL") { |v| options[:post_logout_redirect_uri] = v }
  opts.on("--public", "Confidential Clientではなく Public Client(PKCEのみ)として登録する") do
    options[:confidential] = false
  end
  opts.on("--update", "Clientが既に存在する場合、redirectUris等をPATCHで更新する") { options[:update] = true }
end.parse!

abort "エラー: --admin-email は必須です" unless options[:admin_email]
abort "エラー: --admin-password は必須です" unless options[:admin_password]

def request_json(method, url, body: nil, headers: {})
  uri = URI.parse(url)
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = uri.scheme == "https"

  request = method.new(uri)
  request["Content-Type"] = "application/json"
  headers.each { |k, v| request[k] = v }
  request.body = JSON.generate(body) if body

  response = http.request(request)
  parsed = response.body.to_s.empty? ? {} : JSON.parse(response.body)
  [response, parsed]
end

# 1. 管理者ログイン ----------------------------------------------------------
puts "管理者ログイン中... (#{options[:issuer]}/api/v1/auth/login)"

login_response, login_body = request_json(
  Net::HTTP::Post,
  "#{options[:issuer]}/api/v1/auth/login",
  body: { email: options[:admin_email], password: options[:admin_password] }
)

unless login_response.code.to_i == 200
  abort "管理者ログインに失敗しました (#{login_response.code}): #{login_body}"
end

access_token = login_body.fetch("accessToken")
puts "管理者ログイン成功。"

# 2. Client登録 ---------------------------------------------------------------
client_payload = {
  clientId: options[:client_id],
  isPublic: !options[:confidential],
  tokenEndpointAuthMethod: options[:confidential] ? "CLIENT_SECRET_BASIC" : "NONE",
  redirectUris: [options[:redirect_uri]],
  postLogoutRedirectUris: [options[:post_logout_redirect_uri]],
  allowedScopes: %w[openid email profile offline_access groups],
  grantTypes: %w[authorization_code refresh_token]
}

puts "Client '#{options[:client_id]}' を登録中..."

client_response, client_body = request_json(
  Net::HTTP::Post,
  "#{options[:issuer]}/api/v1/clients",
  body: client_payload,
  headers: { "Authorization" => "Bearer #{access_token}" }
)

case client_response.code.to_i
when 201
  puts ""
  puts "登録に成功しました。以下を .env に設定してください:"
  puts ""
  puts "OIDC_ISSUER=#{options[:issuer]}"
  puts "OIDC_CLIENT_ID=#{client_body.fetch('clientId')}"
  puts "OIDC_CLIENT_SECRET=#{client_body['clientSecret']}" if client_body["clientSecret"]
  puts "OIDC_REDIRECT_URI=#{options[:redirect_uri]}"
  puts "OIDC_POST_LOGOUT_REDIRECT_URI=#{options[:post_logout_redirect_uri]}"
  puts ""
  puts "clientSecretはこの初回登録時にしか取得できません。控えておいてください。"
when 409
  puts ""
  puts "Client '#{options[:client_id]}' は既に登録済みです。"

  unless options[:update]
    puts "redirectUris/postLogoutRedirectUrisを最新の値に更新したい場合は --update を付けて再実行してください。"
    puts "clientSecretを再取得したい場合は以下を実行してください:"
    puts ""
    puts "  curl -X POST #{options[:issuer]}/api/v1/clients/#{options[:client_id]}/secret/rotate \\"
    puts "    -H \"Authorization: Bearer #{access_token}\""
    exit 0
  end

  puts "--update が指定されたため、redirectUris/postLogoutRedirectUrisを更新します..."
  puts "(clientSecret自体はPATCHで変更されません。再発行したい場合は上記のsecret/rotateを使ってください)"

  update_response, update_body = request_json(
    Net::HTTP::Patch,
    "#{options[:issuer]}/api/v1/clients/#{options[:client_id]}",
    body: {
      redirectUris: [options[:redirect_uri]],
      postLogoutRedirectUris: [options[:post_logout_redirect_uri]]
    },
    headers: { "Authorization" => "Bearer #{access_token}" }
  )

  if update_response.code.to_i == 200
    puts ""
    puts "更新に成功しました:"
    puts "OIDC_REDIRECT_URI=#{options[:redirect_uri]}"
    puts "OIDC_POST_LOGOUT_REDIRECT_URI=#{options[:post_logout_redirect_uri]}"
  else
    abort "Client更新に失敗しました (#{update_response.code}): #{update_body}"
  end
else
  abort "Client登録に失敗しました (#{client_response.code}): #{client_body}"
end
