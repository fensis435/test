import type { NextFunction, Request, Response } from "express";
import { jwtVerify } from "jose";
import { env } from "../config/env.js";
import { ApiError } from "../infra/http/problem-json.js";

// ----------------------------------------------------------------------------
// Management API(User CRUD / Groups / Webhook等)を保護するための
// 管理者トークン検証ミドルウェア。
// これはエンドユーザー向けOIDCのAccess Tokenとは別の、管理API専用トークン。
// ----------------------------------------------------------------------------

const secretKey = new TextEncoder().encode(env.ADMIN_JWT_SECRET);

export interface AuthenticatedRequest extends Request {
  adminUserId?: string;
}

export async function requireAdminAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    next(new ApiError(401, "unauthorized", "Admin access token is required."));
    return;
  }

  const token = authHeader.slice("Bearer ".length);

  try {
    const { payload } = await jwtVerify(token, secretKey, { algorithms: ["HS256"] });
    req.adminUserId = String(payload.sub);
    next();
  } catch {
    next(new ApiError(401, "unauthorized", "Admin access token is invalid or expired."));
  }
}
