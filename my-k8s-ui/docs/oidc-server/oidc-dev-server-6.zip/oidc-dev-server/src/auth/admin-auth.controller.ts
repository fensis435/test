import type { Request, Response } from "express";
import argon2 from "argon2";
import { SignJWT } from "jose";
import { z } from "zod";
import { prisma } from "../infra/persistence/prisma-client.js";
import { env } from "../config/env.js";
import { ApiError } from "../infra/http/problem-json.js";
import type { AuthenticatedRequest } from "./admin-auth.middleware.js";

// ----------------------------------------------------------------------------
// 人間の管理者がManagement APIツールから使うログイン/ログアウト。
// 前回確認済み: サービス間認証ではなく人間の管理者利用が想定。
// Cognito本番には対応物が存在しないため、この機能は移行時に廃止される
// 前提で設計する(README/ADR記載)。
// ----------------------------------------------------------------------------

export const loginBodySchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const secretKey = new TextEncoder().encode(env.ADMIN_JWT_SECRET);

// 失効済み管理トークンの簡易ブラックリスト(開発用途。プロセス再起動でクリアされる)
const revokedJti = new Set<string>();

export async function login(req: Request, res: Response): Promise<void> {
  const { email, password } = req.body as z.infer<typeof loginBodySchema>;
  const normalizedEmail = email.trim().toLowerCase();

  const adminUser = await prisma.adminUser.findFirst({
    where: { email: normalizedEmail, deletedAt: null },
  });

  // ユーザー列挙攻撃対策: 存在しない場合もダミーハッシュ検証を行い応答時間を揃える
  const passwordHashToVerify =
    adminUser?.passwordHash ?? "$argon2id$v=19$m=65536,t=3,p=4$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  const passwordValid = await argon2.verify(passwordHashToVerify, password).catch(() => false);

  if (!adminUser || !passwordValid) {
    throw new ApiError(401, "invalid-credentials", "Email or password is incorrect.");
  }

  const jti = crypto.randomUUID();
  const accessToken = await new SignJWT({})
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(adminUser.id)
    .setJti(jti)
    .setIssuedAt()
    .setExpirationTime(`${env.ADMIN_JWT_TTL_SECONDS}s`)
    .sign(secretKey);

  const expiresAt = new Date(Date.now() + env.ADMIN_JWT_TTL_SECONDS * 1000);

  res.status(200).json({
    sessionId: jti,
    accessToken,
    expiresAt: expiresAt.toISOString(),
  });
}

export async function logout(req: AuthenticatedRequest, res: Response): Promise<void> {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    // JWTのjtiクレームを取り出してブラックリストに追加(簡易実装)
    const token = authHeader.slice("Bearer ".length);
    const parts = token.split(".");
    if (parts.length === 3) {
      try {
        const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf-8")) as { jti?: string };
        if (payload.jti) revokedJti.add(payload.jti);
      } catch {
        // ignore malformed token; requireAdminAuth already validated signature upstream
      }
    }
  }
  res.status(204).send();
}

export function isRevoked(jti: string): boolean {
  return revokedJti.has(jti);
}
