import express, { type Express } from "express";
import cookieParser from "cookie-parser";
import type Provider from "oidc-provider";
import { createOidcProvider } from "../../oidc-core/provider.js";
import { buildInteractionsRouter } from "../../oidc-core/interactions.js";
import { adminAuthRouter } from "../../auth/admin-auth.routes.js";
import { usersRouter } from "../../identity/users.routes.js";
import { passwordRouter } from "../../identity/password.routes.js";
import { groupsRouter } from "../../identity/groups.routes.js";
import { clientsRouter } from "../../identity/clients.routes.js";
import { webhooksRouter } from "../../webhooks/webhooks.routes.js";
import { errorHandler, notFoundHandler } from "./error-handler.js";

// ----------------------------------------------------------------------------
// アプリケーション構成の境界を明示する。
//
//   1. OIDC Core (oidc-provider本体)
//        - /.well-known/openid-configuration, /authorize, /token,
//          /userinfo, /jwks.json, /logout, /revoke
//        - Reactが直接利用してよい唯一の領域(標準準拠)
//        - /interaction/* (独自ログイン画面)
//
//   2. Management API (/api/v1/*)
//        - User CRUD, Password, Enable/Disable, Groups, 管理者Login/Logout,
//          Webhook
//        - Cognito本番に対応物が存在しないか形態が変わる領域
//        - Reactからの直接利用は禁止。Rails経由でのみ利用される想定
// ----------------------------------------------------------------------------

export function createApp(): { app: Express; provider: Provider } {
  const app = express();
  const provider = createOidcProvider();

  app.disable("x-powered-by");
  app.use(cookieParser());
  app.use(express.json({ type: ["application/json", "application/x-www-form-urlencoded"] }));
  app.use(express.urlencoded({ extended: true }));

  // --- 2. Management API ---------------------------------------------------
  app.use("/api/v1", adminAuthRouter);
  app.use("/api/v1", usersRouter);
  app.use("/api/v1", passwordRouter);
  app.use("/api/v1", groupsRouter);
  app.use("/api/v1", clientsRouter);
  app.use("/api/v1", webhooksRouter);

  // --- 1. OIDC Core: 独自ログイン/Consentインタラクション画面 ---------------
  app.use(buildInteractionsRouter(provider));

  // --- 1. OIDC Core: oidc-provider本体(discovery/authorize/token/jwks等) ---
  app.use(provider.callback());

  app.use(notFoundHandler);
  app.use(errorHandler);

  return { app, provider };
}
