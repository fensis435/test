import { createHash } from "node:crypto";
import { prisma } from "../infra/persistence/prisma-client.js";

// ----------------------------------------------------------------------------
// oidc-provider が要求する Adapter インターフェースの実装。
//
// 設計方針:
//   - Client / AuthorizationCode / RefreshToken は、前回のDB設計で定義した
//     業務テーブル(clients / authorization_codes / refresh_tokens)に
//     そのままマッピングする。仕様(ER図・PK・FK・Index)は変更しない。
//   - それ以外の oidc-provider 内部モデル(Session, Interaction, Grant,
//     DeviceCode, BackchannelAuthenticationRequest,
//     PushedAuthorizationRequest, ReplayDetection, AccessToken,
//     RegistrationAccessToken, InitialAccessToken)は、業務要件の設計対象外
//     (oidc-providerの内部実装詳細)であるため、汎用KVストア
//     (OidcGenericStore)に格納する。
// ----------------------------------------------------------------------------

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

interface AdapterPayload {
  [key: string]: unknown;
  grantId?: string;
  userCode?: string;
  uid?: string;
}

export class PrismaOidcAdapter {
  public readonly model: string;

  constructor(name: string) {
    this.model = name;
  }

  async upsert(id: string, payload: AdapterPayload, expiresIn: number): Promise<void> {
    switch (this.model) {
      case "Client":
        await this.upsertClient(id, payload);
        return;
      case "AuthorizationCode":
        await this.upsertAuthorizationCode(id, payload, expiresIn);
        return;
      case "RefreshToken":
        await this.upsertRefreshToken(id, payload, expiresIn);
        return;
      default:
        await this.upsertGeneric(id, payload, expiresIn);
    }
  }

  async find(id: string): Promise<AdapterPayload | undefined> {
    switch (this.model) {
      case "Client":
        return this.findClient(id);
      case "AuthorizationCode":
        return this.findAuthorizationCode(id);
      case "RefreshToken":
        return this.findRefreshToken(id);
      default:
        return this.findGeneric(id);
    }
  }

  async findByUserCode(userCode: string): Promise<AdapterPayload | undefined> {
    const row = await prisma.oidcGenericStore.findFirst({
      where: { modelName: this.model, userCode },
    });
    return row ? (JSON.parse(row.payload) as AdapterPayload) : undefined;
  }

  async findByUid(uid: string): Promise<AdapterPayload | undefined> {
    const row = await prisma.oidcGenericStore.findFirst({
      where: { modelName: this.model, uid },
    });
    return row ? (JSON.parse(row.payload) as AdapterPayload) : undefined;
  }

  async consume(id: string): Promise<void> {
    switch (this.model) {
      case "AuthorizationCode": {
        const codeHash = sha256(id);
        await prisma.authorizationCode.updateMany({
          where: { codeHash },
          data: { usedAt: new Date() },
        });
        return;
      }
      case "RefreshToken": {
        const tokenHash = sha256(id);
        await prisma.refreshToken.updateMany({
          where: { tokenHash },
          data: { revokedAt: new Date(), revokedReason: "CONSUMED" },
        });
        return;
      }
      default: {
        await prisma.oidcGenericStore.updateMany({
          where: { modelName: this.model, key: id },
          data: { consumedAt: new Date() },
        });
      }
    }
  }

  async destroy(id: string): Promise<void> {
    switch (this.model) {
      case "AuthorizationCode": {
        const codeHash = sha256(id);
        await prisma.authorizationCode.deleteMany({ where: { codeHash } });
        return;
      }
      case "RefreshToken": {
        const tokenHash = sha256(id);
        await prisma.refreshToken.deleteMany({ where: { tokenHash } });
        return;
      }
      case "Client": {
        await prisma.client.updateMany({ where: { clientId: id }, data: { deletedAt: new Date() } });
        return;
      }
      default: {
        await prisma.oidcGenericStore.deleteMany({ where: { modelName: this.model, key: id } });
      }
    }
  }

  async revokeByGrantId(grantId: string): Promise<void> {
    // RefreshToken / AuthorizationCode は grantId を familyId として保持している。
    await prisma.refreshToken.updateMany({
      where: { familyId: grantId, revokedAt: null },
      data: { revokedAt: new Date(), revokedReason: "GRANT_REVOKED" },
    });
    await prisma.oidcGenericStore.deleteMany({ where: { grantId } });
  }

  // ------------------------------------------------------------------------
  // Client
  // ------------------------------------------------------------------------

  private async upsertClient(id: string, payload: AdapterPayload): Promise<void> {
    const isPublic = payload.token_endpoint_auth_method === "none";
    await prisma.client.upsert({
      where: { clientId: id },
      create: {
        clientId: id,
        clientSecretHash: payload.client_secret ? sha256(String(payload.client_secret)) : null,
        isPublic,
        tokenEndpointAuthMethod: mapAuthMethod(String(payload.token_endpoint_auth_method ?? "none")),
        redirectUris: JSON.stringify(payload.redirect_uris ?? []),
        postLogoutRedirectUris: JSON.stringify(payload.post_logout_redirect_uris ?? []),
        allowedScopes: JSON.stringify(String(payload.scope ?? "").split(" ").filter(Boolean)),
        grantTypes: JSON.stringify(payload.grant_types ?? ["authorization_code", "refresh_token"]),
      },
      update: {
        redirectUris: JSON.stringify(payload.redirect_uris ?? []),
        postLogoutRedirectUris: JSON.stringify(payload.post_logout_redirect_uris ?? []),
        allowedScopes: JSON.stringify(String(payload.scope ?? "").split(" ").filter(Boolean)),
        grantTypes: JSON.stringify(payload.grant_types ?? ["authorization_code", "refresh_token"]),
      },
    });
  }

  private async findClient(id: string): Promise<AdapterPayload | undefined> {
    const client = await prisma.client.findFirst({ where: { clientId: id, deletedAt: null } });
    if (!client) return undefined;

    return {
      client_id: client.clientId,
      client_secret: undefined, // ハッシュのみ保持。平文は返さない。
      token_endpoint_auth_method: mapAuthMethodReverse(client.tokenEndpointAuthMethod),
      redirect_uris: JSON.parse(client.redirectUris),
      post_logout_redirect_uris: JSON.parse(client.postLogoutRedirectUris),
      scope: (JSON.parse(client.allowedScopes) as string[]).join(" "),
      grant_types: JSON.parse(client.grantTypes),
      response_types: ["code"],
    };
  }

  // ------------------------------------------------------------------------
  // AuthorizationCode
  // ------------------------------------------------------------------------

  private async upsertAuthorizationCode(id: string, payload: AdapterPayload, expiresIn: number): Promise<void> {
    const codeHash = sha256(id);
    const expiresAt = new Date(Date.now() + expiresIn * 1000);

    await prisma.authorizationCode.create({
      data: {
        codeHash,
        userId: String(payload.accountId),
        clientId: await resolveClientRowId(String(payload.clientId)),
        redirectUri: String(payload.redirectUri ?? ""),
        codeChallenge: String(payload.codeChallenge ?? ""),
        codeChallengeMethod: (payload.codeChallengeMethod as "S256" | "PLAIN") ?? "S256",
        scope: String(payload.scope ?? ""),
        nonce: payload.nonce ? String(payload.nonce) : null,
        expiresAt,
      },
    });

    // grantId(familyId相当)の相互参照が必要な場合はGenericStoreにも索引を残す
    if (payload.grantId) {
      await prisma.oidcGenericStore.create({
        data: {
          modelName: this.model,
          key: id,
          payload: JSON.stringify(payload),
          grantId: String(payload.grantId),
          expiresAt,
        },
      });
    }
  }

  private async findAuthorizationCode(id: string): Promise<AdapterPayload | undefined> {
    const codeHash = sha256(id);
    const row = await prisma.authorizationCode.findUnique({ where: { codeHash }, include: { client: true } });
    if (!row) return undefined;
    if (row.expiresAt.getTime() < Date.now()) return undefined;

    return {
      accountId: row.userId,
      clientId: row.client.clientId,
      redirectUri: row.redirectUri,
      codeChallenge: row.codeChallenge,
      codeChallengeMethod: row.codeChallengeMethod,
      scope: row.scope,
      nonce: row.nonce ?? undefined,
      consumed: row.usedAt ? Math.floor(row.usedAt.getTime() / 1000) : undefined,
    };
  }

  // ------------------------------------------------------------------------
  // RefreshToken
  // ------------------------------------------------------------------------

  private async upsertRefreshToken(id: string, payload: AdapterPayload, expiresIn: number): Promise<void> {
    const tokenHash = sha256(id);
    const expiresAt = new Date(Date.now() + expiresIn * 1000);
    const familyId = String(payload.grantId ?? id);

    await prisma.refreshToken.create({
      data: {
        tokenHash,
        familyId,
        userId: String(payload.accountId),
        clientId: await resolveClientRowId(String(payload.clientId)),
        scope: String(payload.scope ?? ""),
        expiresAt,
      },
    });
  }

  private async findRefreshToken(id: string): Promise<AdapterPayload | undefined> {
    const tokenHash = sha256(id);
    const row = await prisma.refreshToken.findUnique({ where: { tokenHash }, include: { client: true } });
    if (!row) return undefined;
    if (row.revokedAt) return undefined;
    if (row.expiresAt.getTime() < Date.now()) return undefined;

    return {
      accountId: row.userId,
      clientId: row.client.clientId,
      scope: row.scope,
      grantId: row.familyId,
    };
  }

  // ------------------------------------------------------------------------
  // Generic (Session, Interaction, Grant, DeviceCode, etc.)
  // ------------------------------------------------------------------------

  private async upsertGeneric(id: string, payload: AdapterPayload, expiresIn?: number): Promise<void> {
    const expiresAt = expiresIn ? new Date(Date.now() + expiresIn * 1000) : null;
    await prisma.oidcGenericStore.upsert({
      where: { modelName_key: { modelName: this.model, key: id } },
      create: {
        modelName: this.model,
        key: id,
        payload: JSON.stringify(payload),
        grantId: payload.grantId ?? null,
        userCode: payload.userCode ?? null,
        uid: payload.uid ?? null,
        expiresAt,
      },
      update: {
        payload: JSON.stringify(payload),
        grantId: payload.grantId ?? null,
        userCode: payload.userCode ?? null,
        uid: payload.uid ?? null,
        expiresAt,
      },
    });
  }

  private async findGeneric(id: string): Promise<AdapterPayload | undefined> {
    const row = await prisma.oidcGenericStore.findUnique({
      where: { modelName_key: { modelName: this.model, key: id } },
    });
    if (!row) return undefined;
    if (row.expiresAt && row.expiresAt.getTime() < Date.now()) return undefined;

    const payload = JSON.parse(row.payload) as AdapterPayload;
    if (row.consumedAt) {
      payload.consumed = Math.floor(row.consumedAt.getTime() / 1000);
    }
    return payload;
  }
}

// ----------------------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------------------

function mapAuthMethod(value: string): "NONE" | "CLIENT_SECRET_BASIC" | "CLIENT_SECRET_POST" {
  if (value === "client_secret_basic") return "CLIENT_SECRET_BASIC";
  if (value === "client_secret_post") return "CLIENT_SECRET_POST";
  return "NONE";
}

function mapAuthMethodReverse(value: string): string {
  if (value === "CLIENT_SECRET_BASIC") return "client_secret_basic";
  if (value === "CLIENT_SECRET_POST") return "client_secret_post";
  return "none";
}

async function resolveClientRowId(clientId: string): Promise<string> {
  const client = await prisma.client.findUniqueOrThrow({ where: { clientId } });
  return client.id;
}
