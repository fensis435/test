import { readFileSync } from "node:fs";
import Provider from "oidc-provider";
import { env } from "../config/env.js";
import { PrismaOidcAdapter } from "./adapter.js";
import { claimsConfig, scopesSupported, findAccount, extraAccessTokenClaims } from "./claims.js";

// ----------------------------------------------------------------------------
// oidc-provider 設定方針(前回設計のoidc-provider設定方針節を忠実に反映)
//
//   - features.devInteractions: 無効化(独自ログイン画面を使用)
//   - features.revocation: 有効化(RFC 7009)
//   - features.rpInitiatedLogout: 有効化(標準Logout。Cognitoとの差異は
//     Reactラッパー側で吸収する設計のため、ここは標準のまま)
//   - PKCE: 全クライアントで必須
//   - Cognito固有のクレーム名・スコープ・パラメータは一切定義しない
// ----------------------------------------------------------------------------

function loadJwks(): { keys: unknown[] } {
  const raw = readFileSync(env.OIDC_JWKS_PATH, "utf-8");
  return JSON.parse(raw) as { keys: unknown[] };
}

export function createOidcProvider(): Provider {
  const jwks = loadJwks();

  const provider = new Provider(env.OIDC_ISSUER, {
    adapter: PrismaOidcAdapter,
    jwks,

    findAccount,

    claims: claimsConfig,
    scopes: [...scopesSupported],

    cookies: {
      keys: env.OIDC_COOKIE_KEYS_ARRAY,
      long: { signed: true, sameSite: "lax" },
      short: { signed: true, sameSite: "lax" },
    },

    features: {
      devInteractions: { enabled: false },
      revocation: { enabled: true },
      rpInitiatedLogout: { enabled: true },
      userinfo: { enabled: true },
      resourceIndicators: { enabled: false },
    },

    pkce: {
      required: () => true,
      methods: ["S256"],
    },

    responseTypes: ["code"],

    tokenEndpointAuthMethods: ["none", "client_secret_basic"],

    ttl: {
      AuthorizationCode: 60, // 秒。短命。
      AccessToken: 3600, // 1時間。Cognitoデフォルト相当。
      IdToken: 3600,
      RefreshToken: 2592000, // 30日。Cognitoデフォルト相当。
      Session: 1209600, // 14日。
      Interaction: 3600,
      Grant: 2592000,
    },

    extraTokenClaims: async (_ctx, token) => {
      if (token.kind === "AccessToken") {
        return extraAccessTokenClaims();
      }
      return {};
    },

    interactions: {
      url: (_ctx, interaction) => `/interaction/${interaction.uid}`,
    },

    routes: {
      authorization: "/authorize",
      token: "/token",
      userinfo: "/userinfo",
      jwks: "/jwks.json",
      revocation: "/revoke",
      end_session: "/logout",
    },
  });

  return provider;
}
